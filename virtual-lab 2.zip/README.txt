Virtual Lab (cheminformatics) - standalone web app
1. Unzip the folder.
2. Double-click index.html to open it in any modern browser (Chrome, Safari, Edge, Firefox).
3. An internet connection is needed once per load for the 3D viewer library (3Dmol.js, loaded from cdnjs).
All other features (SMILES parsing, 2D drawing, properties, compare, analysis, assessment, report downloads) run offline.
